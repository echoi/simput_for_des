<template src="./template.html" />
<style module src="./style.css" />
<script src="./script.js" />
